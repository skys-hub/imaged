#ifndef IMAGE_SERVER_H
#define IMAGE_SERVER_H

#include <boost/asio.hpp>
#include <string>
#include <vector>
#include <memory>
#include <unordered_map>
#include <functional>
#include <sqlite3.h>

namespace image_server {

// Image metadata structure
struct ImageMetadata {
    std::string id;
    std::string filename;
    std::string stored_path;
    std::string mime_type;
    size_t file_size;
    size_t width;
    size_t height;
    std::string upload_time;
    std::string upload_ip;
    std::string thumbnail;
};

// Request structure
struct Request {
    std::string method;
    std::string path;
    std::unordered_map<std::string, std::string> headers;
    std::unordered_map<std::string, std::string> query_params;
    std::string body;
    std::string client_ip;
};

// Response structure
struct Response {
    int status_code;
    std::unordered_map<std::string, std::string> headers;
    std::string body;
};

// Multipart form data structure
struct FormPart {
    std::string name;
    std::string filename;
    std::string content_type;
    std::vector<uint8_t> data;
};

// Route handler type
using RouteHandler = std::function<Response(const Request&)>;

// Server class
class ImageServer {
public:
    ImageServer(boost::asio::io_context& io_context, unsigned short port);
    
    void start();
    void add_route(const std::string& path, const RouteHandler& handler);
    
private:
    void accept_connection();
    void handle_connection(std::shared_ptr<boost::asio::ip::tcp::socket> socket);
    void read_request(std::shared_ptr<boost::asio::ip::tcp::socket> socket, std::shared_ptr<std::vector<uint8_t>> buffer);
    Request parse_request(const std::vector<uint8_t>& buffer, const std::string& client_ip);
    std::vector<FormPart> parse_multipart_form_data(const std::string& body, const std::string& boundary);
    Response handle_request(const Request& request);
    void send_response(std::shared_ptr<boost::asio::ip::tcp::socket> socket, const Response& response);
    
    bool init_database();
    bool save_image_metadata(const ImageMetadata& metadata);
    std::vector<ImageMetadata> get_images(int page, int limit, const std::string& sort_by);
    ImageMetadata get_image_by_id(const std::string& id);
    bool delete_image_by_id(const std::string& id);
    
    std::string generate_unique_id();
    std::string get_mime_type(const std::string& filename);
    std::string format_date_time();
    std::string format_file_size(size_t bytes);
    
    bool compress_image(const std::string& input_path, const std::string& output_path, int quality = 80);
    bool create_thumbnail(const std::string& input_path, const std::string& output_path, int max_dimension = 200);
    bool crop_image(const std::string& input_path, const std::string& output_path, int x, int y, int width, int height);
    
    boost::asio::io_context& io_context_;
    boost::asio::ip::tcp::acceptor acceptor_;
    std::unordered_map<std::string, RouteHandler> routes_;
    
    std::string upload_dir_;
    std::string thumbnail_dir_;
    std::string db_path_;
    sqlite3* db_;
};

} // namespace image_server

#endif // IMAGE_SERVER_H
