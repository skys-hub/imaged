#include "image_server.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <random>
#include <ctime>
#include <cstring>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <boost/algorithm/string.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>

// For image processing
#include <gd.h>
#include <gdfontt.h>
#include <gdpp.h>

namespace image_server {

// Helper function to create directory if it doesn't exist
bool create_directory(const std::string& path) {
    struct stat st;
    if (stat(path.c_str(), &st) == 0) {
        return true;
    }
    return mkdir(path.c_str(), 0755) == 0;
}

// Helper function to read file content
std::vector<uint8_t> read_file(const std::string& path) {
    std::ifstream file(path, std::ios::binary);
    if (!file.is_open()) {
        return {};
    }
    
    file.seekg(0, std::ios::end);
    size_t size = file.tellg();
    file.seekg(0, std::ios::beg);
    
    std::vector<uint8_t> data(size);
    file.read(reinterpret_cast<char*>(data.data()), size);
    
    return data;
}

// Helper function to write file content
bool write_file(const std::string& path, const std::vector<uint8_t>& data) {
    std::ofstream file(path, std::ios::binary);
    if (!file.is_open()) {
        return false;
    }
    
    file.write(reinterpret_cast<const char*>(data.data()), data.size());
    return true;
}

// Helper function to get file extension
std::string get_file_extension(const std::string& filename) {
    size_t dot_pos = filename.find_last_of('.');
    if (dot_pos == std::string::npos) {
        return "";
    }
    return filename.substr(dot_pos + 1);
}

// Constructor
ImageServer::ImageServer(boost::asio::io_context& io_context, unsigned short port)
    : io_context_(io_context),
      acceptor_(io_context, boost::asio::ip::tcp::endpoint(boost::asio::ip::tcp::v4(), port)),
      upload_dir_("../uploads/"),
      thumbnail_dir_("../thumbnails/"),
      db_path_("../database/images.db"),
      db_(nullptr) {
    
    // Create upload and thumbnail directories
    create_directory(upload_dir_);
    create_directory(thumbnail_dir_);
    
    // Initialize database
    init_database();
    
    // Setup routes
    setup_routes();
}

// Start the server
void ImageServer::start() {
    accept_connection();
    std::cout << "Server started on port " << acceptor_.local_endpoint().port() << std::endl;
}

// Accept incoming connection
void ImageServer::accept_connection() {
    auto socket = std::make_shared<boost::asio::ip::tcp::socket>(io_context_);
    
    acceptor_.async_accept(*socket, [this, socket](const boost::system::error_code& error) {
        if (!error) {
            handle_connection(socket);
        }
        accept_connection();
    });
}

// Handle client connection
void ImageServer::handle_connection(std::shared_ptr<boost::asio::ip::tcp::socket> socket) {
    auto buffer = std::make_shared<std::vector<uint8_t>>(4096);
    
    socket->async_read_some(boost::asio::buffer(*buffer), [this, socket, buffer](const boost::system::error_code& error, std::size_t bytes_transferred) {
        if (!error) {
            buffer->resize(bytes_transferred);
            read_request(socket, buffer);
        }
    });
}

// Read request data
void ImageServer::read_request(std::shared_ptr<boost::asio::ip::tcp::socket> socket, std::shared_ptr<std::vector<uint8_t>> buffer) {
    // Check if we have the entire request
    // For simplicity, we'll assume the entire request is read in one go
    // In a real server, you'd need to handle chunked requests and content length
    
    std::string client_ip = socket->remote_endpoint().address().to_string();
    Request request = parse_request(*buffer, client_ip);
    Response response = handle_request(request);
    send_response(socket, response);
}

// Parse HTTP request
Request ImageServer::parse_request(const std::vector<uint8_t>& buffer, const std::string& client_ip) {
    Request request;
    request.client_ip = client_ip;
    
    std::string request_str(buffer.begin(), buffer.end());
    std::istringstream request_stream(request_str);
    
    // Parse request line
    std::string request_line;
    std::getline(request_stream, request_line);
    request_line.pop_back(); // Remove \r
    
    std::istringstream request_line_stream(request_line);
    request_line_stream >> request.method >> request.path >> request.http_version;
    
    // Parse query parameters
    size_t query_pos = request.path.find('?');
    if (query_pos != std::string::npos) {
        std::string query_string = request.path.substr(query_pos + 1);
        request.path = request.path.substr(0, query_pos);
        
        std::vector<std::string> query_params;
        boost::split(query_params, query_string, boost::is_any_of("&"));
        
        for (const std::string& param : query_params) {
            std::vector<std::string> key_value;
            boost::split(key_value, param, boost::is_any_of("="));
            if (key_value.size() == 2) {
                request.query_params[key_value[0]] = key_value[1];
            }
        }
    }
    
    // Parse headers
    std::string header_line;
    while (std::getline(request_stream, header_line) && header_line != "\r") {
        header_line.pop_back(); // Remove \r
        
        size_t colon_pos = header_line.find(':');
        if (colon_pos != std::string::npos) {
            std::string key = header_line.substr(0, colon_pos);
            std::string value = header_line.substr(colon_pos + 2); // Skip ": "
            request.headers[key] = value;
        }
    }
    
    // Parse body if present
    if (request.headers.find("Content-Length") != request.headers.end()) {
        size_t content_length = std::stoul(request.headers["Content-Length"]);
        request.body = request_str.substr(request_str.find("\r\n\r\n") + 4, content_length);
    }
    
    return request;
}

// Parse multipart form data
std::vector<FormPart> ImageServer::parse_multipart_form_data(const std::string& body, const std::string& boundary) {
    std::vector<FormPart> parts;
    std::string delimiter = "--" + boundary;
    std::string end_delimiter = delimiter + "--";
    
    size_t pos = 0;
    while (pos < body.size()) {
        // Find the next delimiter
        size_t delimiter_pos = body.find(delimiter, pos);
        if (delimiter_pos == std::string::npos) {
            break;
        }
        
        // Skip the delimiter
        pos = delimiter_pos + delimiter.size();
        
        // Check if this is the end delimiter
        if (body.substr(pos, end_delimiter.size() - delimiter.size()) == "--") {
            break;
        }
        
        // Skip any whitespace
        while (pos < body.size() && (body[pos] == '\r' || body[pos] == '\n')) {
            pos++;
        }
        
        // Parse headers
        FormPart part;
        std::string header_line;
        while (pos < body.size()) {
            size_t line_end = body.find("\r\n", pos);
            if (line_end == std::string::npos) {
                break;
            }
            
            header_line = body.substr(pos, line_end - pos);
            pos = line_end + 2;
            
            // Check for empty line (end of headers)
            if (header_line.empty()) {
                break;
            }
            
            // Parse header
            size_t colon_pos = header_line.find(':');
            if (colon_pos != std::string::npos) {
                std::string key = header_line.substr(0, colon_pos);
                std::string value = header_line.substr(colon_pos + 2);
                
                if (key == "Content-Disposition") {
                    // Parse content disposition
                    std::vector<std::string> params;
                    boost::split(params, value, boost::is_any_of(";"));
                    
                    for (const std::string& param : params) {
                        std::vector<std::string> key_value;
                        boost::split(key_value, param, boost::is_any_of("="));
                        if (key_value.size() == 2) {
                            std::string param_key = boost::trim_copy(key_value[0]);
                            std::string param_value = boost::trim_copy(key_value[1]);
                            
                            // Remove quotes
                            if (param_value.front() == '"' && param_value.back() == '"') {
                                param_value = param_value.substr(1, param_value.size() - 2);
                            }
                            
                            if (param_key == "name") {
                                part.name = param_value;
                            } else if (param_key == "filename") {
                                part.filename = param_value;
                            }
                        }
                    }
                } else if (key == "Content-Type") {
                    part.content_type = value;
                }
            }
        }
        
        // Find the end of the part
        size_t part_end = body.find(delimiter, pos);
        if (part_end == std::string::npos) {
            part_end = body.find(end_delimiter, pos);
        }
        
        if (part_end != std::string::npos) {
            // Extract part data (excluding the trailing \r\n before the delimiter)
            size_t data_end = part_end;
            if (data_end >= 2 && body.substr(data_end - 2, 2) == "\r\n") {
                data_end -= 2;
            }
            
            part.data.assign(body.begin() + pos, body.begin() + data_end);
            pos = part_end;
            
            parts.push_back(part);
        } else {
            break;
        }
    }
    
    return parts;
}

// Handle HTTP request
Response ImageServer::handle_request(const Request& request) {
    Response response;
    response.status_code = 404;
    response.headers["Content-Type"] = "text/plain";
    response.body = "Not Found";
    
    // Check if the route exists
    auto it = routes_.find(request.path);
    if (it != routes_.end()) {
        response = it->second(request);
    }
    
    // Set default headers
    if (response.headers.find("Content-Type") == response.headers.end()) {
        response.headers["Content-Type"] = "text/plain";
    }
    
    response.headers["Server"] = "ImageServer/1.0";
    response.headers["Connection"] = "close";
    response.headers["Content-Length"] = std::to_string(response.body.size());
    
    return response;
}

// Send HTTP response
void ImageServer::send_response(std::shared_ptr<boost::asio::ip::tcp::socket> socket, const Response& response) {
    std::stringstream response_stream;
    
    // Status line
    response_stream << "HTTP/1.1 " << response.status_code << " " << get_status_message(response.status_code) << "\r\n";
    
    // Headers
    for (const auto& header : response.headers) {
        response_stream << header.first << ": " << header.second << "\r\n";
    }
    
    // Empty line
    response_stream << "\r\n";
    
    // Body
    response_stream << response.body;
    
    std::string response_str = response_stream.str();
    
    boost::asio::async_write(*socket, boost::asio::buffer(response_str),
        [socket](const boost::system::error_code& error, std::size_t bytes_transferred) {
            // Connection will be closed automatically after response is sent
        });
}

// Get HTTP status message
std::string ImageServer::get_status_message(int status_code) {
    switch (status_code) {
        case 200: return "OK";
        case 201: return "Created";
        case 400: return "Bad Request";
        case 404: return "Not Found";
        case 500: return "Internal Server Error";
        default: return "Unknown Status";
    }
}

// Initialize database
bool ImageServer::init_database() {
    int rc = sqlite3_open(db_path_.c_str(), &db_);
    if (rc != SQLITE_OK) {
        std::cerr << "Cannot open database: " << sqlite3_errmsg(db_) << std::endl;
        return false;
    }
    
    // Create images table if it doesn't exist
    const char* create_table_sql = R"(
        CREATE TABLE IF NOT EXISTS images (
            id TEXT PRIMARY KEY,
            filename TEXT NOT NULL,
            stored_path TEXT NOT NULL,
            mime_type TEXT NOT NULL,
            file_size INTEGER NOT NULL,
            width INTEGER NOT NULL,
            height INTEGER NOT NULL,
            upload_time TEXT NOT NULL,
            upload_ip TEXT NOT NULL,
            thumbnail TEXT
        );
    )";
    
    char* err_msg = nullptr;
    rc = sqlite3_exec(db_, create_table_sql, nullptr, nullptr, &err_msg);
    if (rc != SQLITE_OK) {
        std::cerr << "SQL error: " << err_msg << std::endl;
        sqlite3_free(err_msg);
        return false;
    }
    
    return true;
}

// Save image metadata to database
bool ImageServer::save_image_metadata(const ImageMetadata& metadata) {
    const char* insert_sql = R"(
        INSERT INTO images (id, filename, stored_path, mime_type, file_size, width, height, upload_time, upload_ip, thumbnail)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
    )";
    
    sqlite3_stmt* stmt;
    int rc = sqlite3_prepare_v2(db_, insert_sql, -1, &stmt, nullptr);
    if (rc != SQLITE_OK) {
        std::cerr << "Failed to prepare statement: " << sqlite3_errmsg(db_) << std::endl;
        return false;
    }
    
    sqlite3_bind_text(stmt, 1, metadata.id.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 2, metadata.filename.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 3, metadata.stored_path.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 4, metadata.mime_type.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_int64(stmt, 5, metadata.file_size);
    sqlite3_bind_int(stmt, 6, metadata.width);
    sqlite3_bind_int(stmt, 7, metadata.height);
    sqlite3_bind_text(stmt, 8, metadata.upload_time.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 9, metadata.upload_ip.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 10, metadata.thumbnail.c_str(), -1, SQLITE_STATIC);
    
    rc = sqlite3_step(stmt);
    if (rc != SQLITE_DONE) {
        std::cerr << "Failed to execute statement: " << sqlite3_errmsg(db_) << std::endl;
        sqlite3_finalize(stmt);
        return false;
    }
    
    sqlite3_finalize(stmt);
    return true;
}

// Get images from database
std::vector<ImageMetadata> ImageServer::get_images(int page, int limit, const std::string& sort_by) {
    std::vector<ImageMetadata> images;
    
    std::string sort_column = "upload_time";
    std::string sort_order = "DESC";
    
    if (sort_by == "date-asc") {
        sort_order = "ASC";
    } else if (sort_by == "name-asc") {
        sort_column = "filename";
        sort_order = "ASC";
    } else if (sort_by == "name-desc") {
        sort_column = "filename";
        sort_order = "DESC";
    }
    
    int offset = (page - 1) * limit;
    
    std::stringstream sql_stream;
    sql_stream << "SELECT id, filename, stored_path, mime_type, file_size, width, height, upload_time, upload_ip, thumbnail "
               << "FROM images "
               << "ORDER BY " << sort_column << " " << sort_order << " "
               << "LIMIT " << limit << " OFFSET " << offset;
    
    sqlite3_stmt* stmt;
    int rc = sqlite3_prepare_v2(db_, sql_stream.str().c_str(), -1, &stmt, nullptr);
    if (rc != SQLITE_OK) {
        std::cerr << "Failed to prepare statement: " << sqlite3_errmsg(db_) << std::endl;
        return images;
    }
    
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        ImageMetadata metadata;
        metadata.id = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 0));
        metadata.filename = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
        metadata.stored_path = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2));
        metadata.mime_type = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3));
        metadata.file_size = sqlite3_column_int64(stmt, 4);
        metadata.width = sqlite3_column_int(stmt, 5);
        metadata.height = sqlite3_column_int(stmt, 6);
        metadata.upload_time = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 7));
        metadata.upload_ip = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 8));
        metadata.thumbnail = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 9));
        
        images.push_back(metadata);
    }
    
    sqlite3_finalize(stmt);
    return images;
}

// Get image by ID
ImageMetadata ImageServer::get_image_by_id(const std::string& id) {
    ImageMetadata metadata;
    
    const char* sql = R"(
        SELECT id, filename, stored_path, mime_type, file_size, width, height, upload_time, upload_ip, thumbnail
        FROM images
        WHERE id = ?;
    )";
    
    sqlite3_stmt* stmt;
    int rc = sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr);
    if (rc != SQLITE_OK) {
        std::cerr << "Failed to prepare statement: " << sqlite3_errmsg(db_) << std::endl;
        return metadata;
    }
    
    sqlite3_bind_text(stmt, 1, id.c_str(), -1, SQLITE_STATIC);
    
    if (sqlite3_step(stmt) == SQLITE_ROW) {
        metadata.id = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 0));
        metadata.filename = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
        metadata.stored_path = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2));
        metadata.mime_type = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3));
        metadata.file_size = sqlite3_column_int64(stmt, 4);
        metadata.width = sqlite3_column_int(stmt, 5);
        metadata.height = sqlite3_column_int(stmt, 6);
        metadata.upload_time = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 7));
        metadata.upload_ip = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 8));
        metadata.thumbnail = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 9));
    }
    
    sqlite3_finalize(stmt);
    return metadata;
}

// Delete image by ID
bool ImageServer::delete_image_by_id(const std::string& id) {
    // First get the image metadata to delete the files
    ImageMetadata metadata = get_image_by_id(id);
    if (metadata.id.empty()) {
        return false;
    }
    
    // Delete the image file
    if (!metadata.stored_path.empty()) {
        remove(metadata.stored_path.c_str());
    }
    
    // Delete the thumbnail
    if (!metadata.thumbnail.empty()) {
        remove(metadata.thumbnail.c_str());
    }
    
    // Delete from database
    const char* sql = "DELETE FROM images WHERE id = ?;";
    
    sqlite3_stmt* stmt;
    int rc = sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr);
    if (rc != SQLITE_OK) {
        std::cerr << "Failed to prepare statement: " << sqlite3_errmsg(db_) << std::endl;
        return false;
    }
    
    sqlite3_bind_text(stmt, 1, id.c_str(), -1, SQLITE_STATIC);
    
    rc = sqlite3_step(stmt);
    if (rc != SQLITE_DONE) {
        std::cerr << "Failed to execute statement: " << sqlite3_errmsg(db_) << std::endl;
        sqlite3_finalize(stmt);
        return false;
    }
    
    sqlite3_finalize(stmt);
    return true;
}

// Generate unique ID
std::string ImageServer::generate_unique_id() {
    static const char chars[] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    static std::random_device rd;
    static std::mt19937 gen(rd());
    static std::uniform_int_distribution<> dis(0, sizeof(chars) - 2);
    
    std::string id;
    for (int i = 0; i < 16; ++i) {
        id += chars[dis(gen)];
    }
    
    return id;
}

// Get MIME type from filename
std::string ImageServer::get_mime_type(const std::string& filename) {
    std::string extension = get_file_extension(filename);
    boost::to_lower(extension);
    
    if (extension == "jpg" || extension == "jpeg") {
        return "image/jpeg";
    } else if (extension == "png") {
        return "image/png";
    } else if (extension == "gif") {
        return "image/gif";
    } else if (extension == "bmp") {
        return "image/bmp";
    } else if (extension == "webp") {
        return "image/webp";
    }
    
    return "application/octet-stream";
}

// Format date time
std::string ImageServer::format_date_time() {
    boost::posix_time::ptime now = boost::posix_time::second_clock::local_time();
    return boost::posix_time::to_iso_extended_string(now);
}

// Format file size
std::string ImageServer::format_file_size(size_t bytes) {
    if (bytes < 1024) {
        return std::to_string(bytes) + " B";
    } else if (bytes < 1024 * 1024) {
        return std::to_string(static_cast<double>(bytes) / 1024) + " KB";
    } else {
        return std::to_string(static_cast<double>(bytes) / (1024 * 1024)) + " MB";
    }
}

// Compress image
bool ImageServer::compress_image(const std::string& input_path, const std::string& output_path, int quality) {
    gdImagePtr img = gdImageCreateFromFile(input_path.c_str());
    if (!img) {
        return false;
    }
    
    FILE* output_file = fopen(output_path.c_str(), "wb");
    if (!output_file) {
        gdImageDestroy(img);
        return false;
    }
    
    std::string extension = get_file_extension(output_path);
    boost::to_lower(extension);
    
    if (extension == "jpg" || extension == "jpeg") {
        gdImageJpeg(img, output_file, quality);
    } else if (extension == "png") {
        gdImagePngEx(img, output_file, 6); // Compression level 0-9
    } else {
        gdImageDestroy(img);
        fclose(output_file);
        return false;
    }
    
    gdImageDestroy(img);
    fclose(output_file);
    return true;
}

// Create thumbnail
bool ImageServer::create_thumbnail(const std::string& input_path, const std::string& output_path, int max_dimension) {
    gdImagePtr img = gdImageCreateFromFile(input_path.c_str());
    if (!img) {
        return false;
    }
    
    int width = gdImageSX(img);
    int height = gdImageSY(img);
    
    // Calculate new dimensions while maintaining aspect ratio
    int new_width, new_height;
    if (width > height) {
        new_width = max_dimension;
        new_height = static_cast<int>(static_cast<double>(height) * new_width / width);
    } else {
        new_height = max_dimension;
        new_width = static_cast<int>(static_cast<double>(width) * new_height / height);
    }
    
    gdImagePtr thumbnail = gdImageCreateTrueColor(new_width, new_height);
    if (!thumbnail) {
        gdImageDestroy(img);
        return false;
    }
    
    // Copy and resize the image
    gdImageCopyResampled(thumbnail, img, 0, 0, 0, 0, new_width, new_height, width, height);
    
    FILE* output_file = fopen(output_path.c_str(), "wb");
    if (!output_file) {
        gdImageDestroy(img);
        gdImageDestroy(thumbnail);
        return false;
    }
    
    std::string extension = get_file_extension(output_path);
    boost::to_lower(extension);
    
    if (extension == "jpg" || extension == "jpeg") {
        gdImageJpeg(thumbnail, output_file, 80);
    } else if (extension == "png") {
        gdImagePngEx(thumbnail, output_file, 6);
    } else {
        gdImageDestroy(img);
        gdImageDestroy(thumbnail);
        fclose(output_file);
        return false;
    }
    
    gdImageDestroy(img);
    gdImageDestroy(thumbnail);
    fclose(output_file);
    return true;
}

// Crop image
bool ImageServer::crop_image(const std::string& input_path, const std::string& output_path, int x, int y, int width, int height) {
    gdImagePtr img = gdImageCreateFromFile(input_path.c_str());
    if (!img) {
        return false;
    }
    
    // Create new image for the crop
    gdImagePtr cropped = gdImageCreateTrueColor(width, height);
    if (!cropped) {
        gdImageDestroy(img);
        return false;
    }
    
    // Copy the cropped region
    gdImageCopy(cropped, img, 0, 0, x, y, width, height);
    
    FILE* output_file = fopen(output_path.c_str(), "wb");
    if (!output_file) {
        gdImageDestroy(img);
        gdImageDestroy(cropped);
        return false;
    }
    
    std::string extension = get_file_extension(output_path);
    boost::to_lower(extension);
    
    if (extension == "jpg" || extension == "jpeg") {
        gdImageJpeg(cropped, output_file, 90);
    } else if (extension == "png") {
        gdImagePngEx(cropped, output_file, 6);
    } else {
        gdImageDestroy(img);
        gdImageDestroy(cropped);
        fclose(output_file);
        return false;
    }
    
    gdImageDestroy(img);
    gdImageDestroy(cropped);
    fclose(output_file);
    return true;
}

// Setup routes
void ImageServer::setup_routes() {
    // API routes
    add_route("/api/upload", [this](const Request& request) {
        return handle_upload(request);
    });
    
    add_route("/api/images", [this](const Request& request) {
        return handle_get_images(request);
    });
    
    add_route("/api/image", [this](const Request& request) {
        if (request.method == "GET") {
            return handle_get_image(request);
        } else if (request.method == "DELETE") {
            return handle_delete_image(request);
        } else {
            Response response;
            response.status_code = 405;
            response.body = "Method Not Allowed";
            return response;
        }
    });
    
    add_route("/api/image/process", [this](const Request& request) {
        return handle_process_image(request);
    });
    
    // Static file routes
    add_route("/", [this](const Request& request) {
        return serve_static_file("../frontend/index.html");
    });
    
    add_route("/images", [this](const Request& request) {
        std::string image_path = upload_dir_ + request.path.substr(7); // Remove "/images/" prefix
        return serve_static_file(image_path);
    });
    
    add_route("/thumbnails", [this](const Request& request) {
        std::string thumbnail_path = thumbnail_dir_ + request.path.substr(11); // Remove "/thumbnails/" prefix
        return serve_static_file(thumbnail_path);
    });
    
    // Serve other static files from frontend directory
    add_route("/css", [this](const Request& request) {
        return serve_static_file("../frontend" + request.path);
    });
    
    add_route("/js", [this](const Request& request) {
        return serve_static_file("../frontend" + request.path);
    });
    
    add_route("/assets", [this](const Request& request) {
        return serve_static_file("../frontend" + request.path);
    });
}

// Handle image upload
Response ImageServer::handle_upload(const Request& request) {
    Response response;
    
    if (request.method != "POST") {
        response.status_code = 405;
        response.body = "Method Not Allowed";
        return response;
    }
    
    // Check if content type is multipart/form-data
    auto content_type_it = request.headers.find("Content-Type");
    if (content_type_it == request.headers.end() || 
        content_type_it->second.find("multipart/form-data") == std::string::npos) {
        response.status_code = 400;
        response.body = "Bad Request: Expected multipart/form-data";
        return response;
    }
    
    // Extract boundary
    std::string content_type = content_type_it->second;
    size_t boundary_pos = content_type.find("boundary=");
    if (boundary_pos == std::string::npos) {
        response.status_code = 400;
        response.body = "Bad Request: Missing boundary";
        return response;
    }
    
    std::string boundary = content_type.substr(boundary_pos + 9);
    
    // Parse multipart form data
    std::vector<FormPart> parts = parse_multipart_form_data(request.body, boundary);
    
    if (parts.empty()) {
        response.status_code = 400;
        response.body = "Bad Request: No files uploaded";
        return response;
    }
    
    // Process each uploaded file
    std::vector<ImageMetadata> uploaded_images;
    
    for (const FormPart& part : parts) {
        if (part.name == "file" && !part.filename.empty()) {
            // Generate unique ID and filename
            std::string id = generate_unique_id();
            std::string extension = get_file_extension(part.filename);
            std::string stored_filename = id + "." + extension;
            std::string stored_path = upload_dir_ + stored_filename;
            
            // Write the file to disk
            if (!write_file(stored_path, part.data)) {
                response.status_code = 500;
                response.body = "Internal Server Error: Failed to save file";
                return response;
            }
            
            // Get image dimensions using GD
            gdImagePtr img = gdImageCreateFromFile(stored_path.c_str());
            if (!img) {
                // Not an image or unsupported format
                remove(stored_path.c_str());
                continue;
            }
            
            int width = gdImageSX(img);
            int height = gdImageSY(img);
            gdImageDestroy(img);
            
            // Create thumbnail
            std::string thumbnail_filename = id + "_thumb." + extension;
            std::string thumbnail_path = thumbnail_dir_ + thumbnail_filename;
            create_thumbnail(stored_path, thumbnail_path, 200);
            
            // Check if compression is requested
            bool compress = false;
            for (const FormPart& p : parts) {
                if (p.name == "compress" && p.data == "true") {
                    compress = true;
                    break;
                }
            }
            
            if (compress) {
                // Compress the image
                std::string compressed_path = stored_path + ".tmp";
                if (compress_image(stored_path, compressed_path, 80)) {
                    // Replace original with compressed version
                    remove(stored_path.c_str());
                    rename(compressed_path.c_str(), stored_path.c_str());
                }
            }
            
            // Get file size
            struct stat st;
            stat(stored_path.c_str(), &st);
            size_t file_size = st.st_size;
            
            // Create metadata
            ImageMetadata metadata;
            metadata.id = id;
            metadata.filename = part.filename;
            metadata.stored_path = stored_path;
            metadata.mime_type = get_mime_type(part.filename);
            metadata.file_size = file_size;
            metadata.width = width;
            metadata.height = height;
            metadata.upload_time = format_date_time();
            metadata.upload_ip = request.client_ip;
            metadata.thumbnail = thumbnail_path;
            
            // Save metadata to database
            if (save_image_metadata(metadata)) {
                uploaded_images.push_back(metadata);
            } else {
                // Clean up if database save fails
                remove(stored_path.c_str());
                remove(thumbnail_path.c_str());
            }
        }
    }
    
    if (uploaded_images.empty()) {
        response.status_code = 400;
        response.body = "Bad Request: No valid images uploaded";
        return response;
    }
    
    // Return JSON response
    response.status_code = 200;
    response.headers["Content-Type"] = "application/json";
    
    response.body = "[";
    for (size_t i = 0; i < uploaded_images.size(); ++i) {
        const ImageMetadata& img = uploaded_images[i];
        
        response.body += "{";
        response.body += "\"id\":\"" + img.id + "\",";
        response.body += "\"filename\":\"" + img.filename + "\",";
        response.body += "\"url\":\"/images/" + img.id + "." + get_file_extension(img.filename) + "\",";
        response.body += "\"thumbnail\":\"/thumbnails/" + img.id + "_thumb." + get_file_extension(img.filename) + "\",";
        response.body += "\"size\":\"" + format_file_size(img.file_size) + "\",";
        response.body += "\"dimensions\":\"" + std::to_string(img.width) + " × " + std::to_string(img.height) + "\",";
        response.body += "\"uploaded\":\"" + img.upload_time + "\"";
        response.body += "}";
        
        if (i < uploaded_images.size() - 1) {
            response.body += ",";
        }
    }
    response.body += "]";
    
    return response;
}

// Handle get images request
Response ImageServer::handle_get_images(const Request& request) {
    Response response;
    
    if (request.method != "GET") {
        response.status_code = 405;
        response.body = "Method Not Allowed";
        return response;
    }
    
    // Get query parameters
    int page = 1;
    int limit = 20;
    std::string sort_by = "date-desc";
    
    if (request.query_params.find("page") != request.query_params.end()) {
        page = std::stoi(request.query_params["page"]);
    }
    
    if (request.query_params.find("limit") != request.query_params.end()) {
        limit = std::stoi(request.query_params["limit"]);
    }
    
    if (request.query_params.find("sort") != request.query_params.end()) {
        sort_by = request.query_params["sort"];
    }
    
    // Get images from database
    std::vector<ImageMetadata> images = get_images(page, limit, sort_by);
    
    // Return JSON response
    response.status_code = 200;
    response.headers["Content-Type"] = "application/json";
    
    response.body = "[";
    for (size_t i = 0; i < images.size(); ++i) {
        const ImageMetadata& img = images[i];
        
        response.body += "{";
        response.body += "\"id\":\"" + img.id + "\",";
        response.body += "\"filename\":\"" + img.filename + "\",";
        response.body += "\"url\":\"/images/" + img.id + "." + get_file_extension(img.filename) + "\",";
        response.body += "\"thumbnail\":\"/thumbnails/" + img.id + "_thumb." + get_file_extension(img.filename) + "\",";
        response.body += "\"size\":\"" + format_file_size(img.file_size) + "\",";
        response.body += "\"dimensions\":\"" + std::to_string(img.width) + " × " + std::to_string(img.height) + "\",";
        response.body += "\"uploaded\":\"" + img.upload_time + "\"";
        response.body += "}";
        
        if (i < images.size() - 1) {
            response.body += ",";
        }
    }
    response.body += "]";
    
    return response;
}

// Handle get image request
Response ImageServer::handle_get_image(const Request& request) {
    Response response;
    
    if (request.query_params.find("id") == request.query_params.end()) {
        response.status_code = 400;
        response.body = "Bad Request: Missing image ID";
        return response;
    }
    
    std::string id = request.query_params["id"];
    
    // Get image metadata from database
    ImageMetadata metadata = get_image_by_id(id);
    if (metadata.id.empty()) {
        response.status_code = 404;
        response.body = "Not Found: Image not found";
        return response;
    }
    
    // Return JSON response
    response.status_code = 200;
    response.headers["Content-Type"] = "application/json";
    
    response.body = "{";
    response.body += "\"id\":\"" + metadata.id + "\",";
    response.body += "\"filename\":\"" + metadata.filename + "\",";
    response.body += "\"url\":\"/images/" + metadata.id + "." + get_file_extension(metadata.filename) + "\",";
    response.body += "\"thumbnail\":\"/thumbnails/" + metadata.id + "_thumb." + get_file_extension(metadata.filename) + "\",";
    response.body += "\"size\":\"" + format_file_size(metadata.file_size) + "\",";
    response.body += "\"dimensions\":\"" + std::to_string(metadata.width) + " × " + std::to_string(metadata.height) + "\",";
    response.body += "\"uploaded\":\"" + metadata.upload_time + "\"";
    response.body += "}";
    
    return response;
}

// Handle delete image request
Response ImageServer::handle_delete_image(const Request& request) {
    Response response;
    
    if (request.query_params.find("id") == request.query_params.end()) {
        response.status_code = 400;
        response.body = "Bad Request: Missing image ID";
        return response;
    }
    
    std::string id = request.query_params["id"];
    
    // Delete image from database and file system
    if (delete_image_by_id(id)) {
        response.status_code = 200;
        response.body = "OK: Image deleted successfully";
    } else {
        response.status_code = 404;
        response.body = "Not Found: Image not found";
    }
    
    return response;
}

// Handle process image request
Response ImageServer::handle_process_image(const Request& request) {
    Response response;
    
    if (request.method != "POST") {
        response.status_code = 405;
        response.body = "Method Not Allowed";
        return response;
    }
    
    // Check if content type is multipart/form-data
    auto content_type_it = request.headers.find("Content-Type");
    if (content_type_it == request.headers.end() || 
        content_type_it->second.find("multipart/form-data") == std::string::npos) {
        response.status_code = 400;
        response.body = "Bad Request: Expected multipart/form-data";
        return response;
    }
    
    // Extract boundary
    std::string content_type = content_type_it->second;
    size_t boundary_pos = content_type.find("boundary=");
    if (boundary_pos == std::string::npos) {
        response.status_code = 400;
        response.body = "Bad Request: Missing boundary";
        return response;
    }
    
    std::string boundary = content_type.substr(boundary_pos + 9);
    
    // Parse multipart form data
    std::vector<FormPart> parts = parse_multipart_form_data(request.body, boundary);
    
    // Extract parameters
    std::string id;
    std::string action;
    int x = 0, y = 0, width = 0, height = 0;
    int quality = 80;
    
    for (const FormPart& part : parts) {
        if (part.name == "id") {
            id = std::string(part.data.begin(), part.data.end());
        } else if (part.name == "action") {
            action = std::string(part.data.begin(), part.data.end());
        } else if (part.name == "x") {
            x = std::stoi(std::string(part.data.begin(), part.data.end()));
        } else if (part.name == "y") {
            y = std::stoi(std::string(part.data.begin(), part.data.end()));
        } else if (part.name == "width") {
            width = std::stoi(std::string(part.data.begin(), part.data.end()));
        } else if (part.name == "height") {
            height = std::stoi(std::string(part.data.begin(), part.data.end()));
        } else if (part.name == "quality") {
            quality = std::stoi(std::string(part.data.begin(), part.data.end()));
        }
    }
    
    if (id.empty() || action.empty()) {
        response.status_code = 400;
        response.body = "Bad Request: Missing ID or action";
        return response;
    }
    
    // Get image metadata from database
    ImageMetadata metadata = get_image_by_id(id);
    if (metadata.id.empty()) {
        response.status_code = 404;
        response.body = "Not Found: Image not found";
        return response;
    }
    
    // Process the image
    if (action == "compress") {
        // Compress the image
        std::string compressed_path = metadata.stored_path + ".tmp";
        if (compress_image(metadata.stored_path, compressed_path, quality)) {
            // Replace original with compressed version
            remove(metadata.stored_path.c_str());
            rename(compressed_path.c_str(), metadata.stored_path.c_str());
            
            // Update file size
            struct stat st;
            stat(metadata.stored_path.c_str(), &st);
            metadata.file_size = st.st_size;
            
            // Update database (in a real application)
            // For now, we'll just return success
            
            response.status_code = 200;
            response.body = "OK: Image compressed successfully";
        } else {
            response.status_code = 500;
            response.body = "Internal Server Error: Failed to compress image";
        }
    } else if (action == "crop") {
        if (width <= 0 || height <= 0) {
            response.status_code = 400;
            response.body = "Bad Request: Invalid crop dimensions";
            return response;
        }
        
        // Generate new ID for the cropped image
        std::string new_id = generate_unique_id();
        std::string extension = get_file_extension(metadata.filename);
        std::string new_filename = new_id + "." + extension;
        std::string new_path = upload_dir_ + new_filename;
        
        // Crop the image
        if (crop_image(metadata.stored_path, new_path, x, y, width, height)) {
            // Create thumbnail for the cropped image
            std::string thumbnail_filename = new_id + "_thumb." + extension;
            std::string thumbnail_path = thumbnail_dir_ + thumbnail_filename;
            create_thumbnail(new_path, thumbnail_path, 200);
            
            // Get file size
            struct stat st;
            stat(new_path.c_str(), &st);
            size_t file_size = st.st_size;
            
            // Create metadata for the new image
            ImageMetadata new_metadata;
            new_metadata.id = new_id;
            new_metadata.filename = "cropped_" + metadata.filename;
            new_metadata.stored_path = new_path;
            new_metadata.mime_type = metadata.mime_type;
            new_metadata.file_size = file_size;
            new_metadata.width = width;
            new_metadata.height = height;
            new_metadata.upload_time = format_date_time();
            new_metadata.upload_ip = request.client_ip;
            new_metadata.thumbnail = thumbnail_path;
            
            // Save metadata to database
            if (save_image_metadata(new_metadata)) {
                // Return JSON response with new image info
                response.status_code = 200;
                response.headers["Content-Type"] = "application/json";
                
                response.body = "{";
                response.body += "\"id\":\"" + new_metadata.id + "\",";
                response.body += "\"filename\":\"" + new_metadata.filename + "\",";
                response.body += "\"url\":\"/images/" + new_metadata.id + "." + extension + "\",";
                response.body += "\"thumbnail\":\"/thumbnails/" + new_metadata.id + "_thumb." + extension + "\",";
                response.body += "\"size\":\"" + format_file_size(new_metadata.file_size) + "\",";
                response.body += "\"dimensions\":\"" + std::to_string(new_metadata.width) + " × " + std::to_string(new_metadata.height) + "\",";
                response.body += "\"uploaded\":\"" + new_metadata.upload_time + "\"";
                response.body += "}";
            } else {
                // Clean up if database save fails
                remove(new_path.c_str());
                remove(thumbnail_path.c_str());
                
                response.status_code = 500;
                response.body = "Internal Server Error: Failed to save cropped image";
            }
        } else {
            response.status_code = 500;
            response.body = "Internal Server Error: Failed to crop image";
        }
    } else {
        response.status_code = 400;
        response.body = "Bad Request: Invalid action";
    }
    
    return response;
}

// Serve static file
Response ImageServer::serve_static_file(const std::string& path) {
    Response response;
    
    // Read file content
    std::vector<uint8_t> content = read_file(path);
    if (content.empty()) {
        response.status_code = 404;
        response.body = "Not Found";
        return response;
    }
    
    // Set content type
    std::string extension = get_file_extension(path);
    response.headers["Content-Type"] = get_mime_type(path);
    
    // Set response body
    response.status_code = 200;
    response.body = std::string(content.begin(), content.end());
    
    return response;
}

} // namespace image_server
