#include <iostream>
#include <boost/asio.hpp>
#include "image_server.h"

int main(int argc, char* argv[]) {
    try {
        // Check command line arguments
        if (argc != 2) {
            std::cerr << "Usage: " << argv[0] << " <port>" << std::endl;
            return 1;
        }
        
        // Get port from command line
        unsigned short port = static_cast<unsigned short>(std::atoi(argv[1]));
        
        // Create io_context
        boost::asio::io_context io_context;
        
        // Create and start the server
        image_server::ImageServer server(io_context, port);
        server.start();
        
        // Run the io_context
        io_context.run();
    } catch (std::exception& e) {
        std::cerr << "Exception: " << e.what() << std::endl;
        return 1;
    }
    
    return 0;
}
