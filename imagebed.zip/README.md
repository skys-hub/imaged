# Simple Image Bed

A lightweight image hosting service built with C++ backend and modern frontend, allowing users to upload, manage, and share images easily.

## Features

- **Image Upload**: Support for drag-and-drop, batch upload, and image preview
- **Image Management**: View uploaded images, preview, copy links, and delete
- **Image Sharing**: Generate direct links, Markdown links, and HTML code
- **Image Processing**: Automatic image compression and simple cropping functionality
- **Responsive Design**: Works on desktop and mobile devices

## Architecture

- **Frontend**: HTML5, CSS3 (Tailwind CSS), JavaScript
- **Backend**: C++ (Boost.Asio for HTTP server)
- **Database**: SQLite for metadata storage
- **Image Processing**: GD library for image manipulation

## Prerequisites

- Ubuntu 20.04 LTS or later
- C++17 compiler
- Boost libraries
- SQLite3
- GD library

## Installation

### 1. Update system packages

```bash
sudo apt update
sudo apt upgrade
```

### 2. Install required dependencies

```bash
sudo apt install build-essential libboost-all-dev libsqlite3-dev libgd-dev
```

### 3. Clone the repository

```bash
git clone https://github.com/yourusername/simple-image-bed.git
cd simple-image-bed
```

### 4. Build the backend server

```bash
cd backend
make
```

### 5. Create necessary directories

```bash
mkdir -p ../uploads ../thumbnails ../database
```

## Usage

### 1. Start the server

```bash
cd backend/build
./image_server 8080
```

The server will start on port 8080. You can change the port by specifying a different number.

### 2. Access the web interface

Open your web browser and navigate to:
```
http://localhost:8080
```

### 3. Upload images

- Drag and drop images into the upload area
- Or click the "Browse Files" button to select images
- You can select multiple images for batch upload

### 4. Manage images

- View all uploaded images in the gallery
- Click on an image to preview and access sharing options
- Use the copy buttons to copy different types of links
- Use the download button to save images locally
- Use the delete button to remove unwanted images

### 5. Image processing

- Enable "Compress Images" option before upload to reduce file size
- Use the crop feature to resize images (available in the image preview modal)

## API Endpoints

### Upload Image

- **URL**: `/api/upload`
- **Method**: `POST`
- **Content-Type**: `multipart/form-data`
- **Parameters**: 
  - `file`: The image file(s) to upload
  - `compress`: Set to "true" to enable image compression
- **Response**: JSON array of uploaded image metadata

### Get Images

- **URL**: `/api/images`
- **Method**: `GET`
- **Query Parameters**:
  - `page`: Page number (default: 1)
  - `limit`: Number of images per page (default: 20)
  - `sort`: Sort order (date-desc, date-asc, name-asc, name-desc)
- **Response**: JSON array of image metadata

### Get Image

- **URL**: `/api/image`
- **Method**: `GET`
- **Query Parameters**:
  - `id`: Image ID
- **Response**: JSON object with image metadata

### Delete Image

- **URL**: `/api/image`
- **Method**: `DELETE`
- **Query Parameters**:
  - `id`: Image ID
- **Response**: Success or error message

### Process Image

- **URL**: `/api/image/process`
- **Method**: `POST`
- **Content-Type**: `multipart/form-data`
- **Parameters**:
  - `id`: Image ID
  - `action`: Process action (compress or crop)
  - `quality`: Compression quality (0-100) for compress action
  - `x`, `y`, `width`, `height`: Crop dimensions for crop action
- **Response**: JSON object with processed image metadata

## Configuration

### Server Configuration

You can modify the following constants in `backend/include/image_server.h`:

- `upload_dir_`: Directory for storing uploaded images (default: "../uploads/")
- `thumbnail_dir_`: Directory for storing thumbnails (default: "../thumbnails/")
- `db_path_`: Path to SQLite database file (default: "../database/images.db")

### Image Processing Configuration

- **Compression Quality**: Default is 80 (out of 100)
- **Thumbnail Size**: Default maximum dimension is 200 pixels

## Security Considerations

- The server currently doesn't implement user authentication. For public use, consider adding user accounts and access control.
- File size and type validation is implemented, but you may want to adjust limits based on your needs.
- The server is designed for personal or small-scale use. For high-traffic scenarios, consider adding a CDN and load balancing.

## Troubleshooting

### Port already in use

If you get an error that the port is already in use, try a different port:

```bash
./image_server 8081
```

### Permission issues

If you encounter permission errors when uploading images, ensure the upload and thumbnail directories have proper permissions:

```bash
chmod 755 ../uploads ../thumbnails ../database
```

### Image processing issues

If image compression or cropping isn't working, ensure the GD library is properly installed:

```bash
sudo apt install libgd-dev
```

## License

This project is licensed under the MIT License - see the LICENSE file for details.
